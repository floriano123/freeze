# frozen_string_literal: true

module Biz
  class Error < StandardError

    Configuration = Class.new(self)

  end
end
