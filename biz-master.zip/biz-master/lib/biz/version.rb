# frozen_string_literal: true

module Biz
  VERSION = '1.8.2'
end
