# frozen_string_literal: true

require 'support/time'
